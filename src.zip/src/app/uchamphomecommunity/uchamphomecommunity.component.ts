import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uchamphomecommunity',
  templateUrl: './uchamphomecommunity.component.html',
  styleUrls: ['./uchamphomecommunity.component.scss']
})
export class UchamphomecommunityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
