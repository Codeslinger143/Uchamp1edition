import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uchamphomeforall',
  templateUrl: './uchamphomeforall.component.html',
  styleUrls: ['./uchamphomeforall.component.scss']
})
export class UchamphomeforallComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
