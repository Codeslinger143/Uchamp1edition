import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uchamphomeone',
  templateUrl: './uchamphomeone.component.html',
  styleUrls: ['./uchamphomeone.component.scss']
})
export class UchamphomeoneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
