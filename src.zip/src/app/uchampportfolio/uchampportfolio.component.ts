import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uchampportfolio',
  templateUrl: './uchampportfolio.component.html',
  styleUrls: ['./uchampportfolio.component.scss']
})
export class UchampportfolioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
