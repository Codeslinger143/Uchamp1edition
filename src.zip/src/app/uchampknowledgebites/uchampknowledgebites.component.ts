import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uchampknowledgebites',
  templateUrl: './uchampknowledgebites.component.html',
  styleUrls: ['./uchampknowledgebites.component.scss']
})
export class UchampknowledgebitesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
