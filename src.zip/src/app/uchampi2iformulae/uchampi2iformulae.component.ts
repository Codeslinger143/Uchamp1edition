import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uchampi2iformulae',
  templateUrl: './uchampi2iformulae.component.html',
  styleUrls: ['./uchampi2iformulae.component.scss']
})
export class Uchampi2iformulaeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
